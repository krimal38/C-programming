/* Do Not Modify This File */
#ifndef FP_PARSE_H
#define FP_PARSE_H

#define ASSIGN 31 
#define PLUS 27
#define PRINT 28
#define EOLN 29
#define FLOAT 30
#define MULT 32

#endif
